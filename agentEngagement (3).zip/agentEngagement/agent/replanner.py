import logging

from .channel_resolver import ChannelResolver
from .context_builder import ProspectEngagementContextBuilder
from .memory_manager import EngagementMemoryManager
from .strategy_planner import EngagementStrategyPlan, EngagementStrategyPlanner

logger = logging.getLogger("agentEngagement.replanner")


class EngagementReplanningService:
    """
    Rebuild context after an analyzed interaction and ask the existing strategy
    planner for a fresh recommendation.

    This service does not encode commercial strategy, generate content, create
    tasks, send messages or mutate Prospect scoring/status fields.
    """

    def __init__(
        self,
        context_builder=None,
        channel_resolver=None,
        strategy_planner=None,
        memory_manager=None,
    ):
        self.context_builder = context_builder or ProspectEngagementContextBuilder()
        self.channel_resolver = channel_resolver or ChannelResolver()
        self.strategy_planner = strategy_planner or EngagementStrategyPlanner()
        self.memory_manager = memory_manager or EngagementMemoryManager()

    def replan(self, prospect, user=None) -> dict:
        context = self.context_builder.build(prospect)
        available_channels = self.channel_resolver.resolve(context)
        plan = self.strategy_planner.plan(
            context=context,
            available_channels=available_channels,
        )
        self._remember_plan(prospect, plan)

        logger.info(
            "[ENGAGEMENT][REPLAN] prospect=%s strategy=%s objective=%s",
            getattr(prospect, "pk", None),
            plan.strategy,
            plan.objective,
        )

        return {
            "context": context,
            "available_channels": available_channels,
            "plan": plan,
        }

    def _remember_plan(self, prospect, plan: EngagementStrategyPlan):
        self.memory_manager.update_from_plan(prospect=prospect, plan=plan)
