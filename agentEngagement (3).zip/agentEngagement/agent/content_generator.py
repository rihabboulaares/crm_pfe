import json
import logging
from typing import Literal

from pydantic import BaseModel, Field

from agentEngagement.gemini_client import extract_json, generate_with_retry, get_gemini_model

from .channel_resolver import ChannelResolver
from .strategy_planner import EngagementStrategyPlan, _model_validate

logger = logging.getLogger("agentEngagement.content_generator")


SOCIAL_CHANNELS = ("linkedin", "facebook", "instagram")


class EngagementContentGenerationUnavailable(Exception):
    """Raised when Gemini cannot provide safe structured engagement content."""


class EmailContent(BaseModel):
    subject: str
    body: str
    tone: str
    objective: str


class CallObjection(BaseModel):
    objection: str
    suggested_response: str


class CallScriptContent(BaseModel):
    call_objective: str
    opening: str
    hook: str
    discovery_questions: list[str] = Field(default_factory=list)
    value_proposition: str
    possible_objections: list[CallObjection] = Field(default_factory=list)
    call_to_action: str
    closing: str


class SocialMessageContent(BaseModel):
    channel: Literal["linkedin", "facebook", "instagram"]
    message: str
    tone: str
    objective: str
    execution_mode: Literal["manual"] = "manual"


class GeneratedEngagementContent(BaseModel):
    content_required: bool
    channel: Literal["email", "phone", "linkedin", "facebook", "instagram"] | None = None
    content_type: Literal["email", "call_script", "social_message"] | None = None
    reason: str = ""
    email: EmailContent | None = None
    call_script: CallScriptContent | None = None
    social_message: SocialMessageContent | None = None


EMAIL_GENERATION_PROMPT = """
You are an expert B2B sales copywriter integrated into a CRM.

Generate a personalized outreach email using only verified CRM data.
Respect the engagement strategy and commercial objective provided.
If the CRM context contains previous interactions or engagement_memory, use them
to write a continuity email. Do not pretend this is a first contact when the
context shows a prior conversation.

Generate all user-facing sales content in French.
Use professional, natural French.
Do not use English unless the prospect context explicitly requires another language.
If no real first name is available, use "Bonjour," instead of inventing or writing
"Bonjour Contact".
The CRM user may work in any industry, and the target contact may have any
professional role. Never assume the target prospect is looking for CRM software,
sales software, prospecting software or marketing software unless verified CRM
context explicitly supports that assumption.
Adapt the email to the prospect's real role, company and known needs. If the
need is not known, stay general and ask to understand the prospect's current
priorities.

Do not invent information.
Do not invent a prospect need, problem, budget, project, technology used,
company news, social post or previous conversation.
Do not write "I saw your recent post" unless a real post is explicitly present
in the CRM context.
Do not fabricate familiarity with the prospect.

The email must sound natural and human.
Avoid generic AI language and excessive marketing claims.
Keep the message concise and relevant, generally 80-180 words.
Do not mention that AI generated the message.

Return only the requested structured JSON output.
""".strip()


CALL_SCRIPT_GENERATION_PROMPT = """
You are an expert sales call coach.

Generate a practical call script for a human sales representative.
The script must help the salesperson conduct a real conversation, not read a
robotic monologue.
If the CRM context contains previous interactions or engagement_memory, adapt the
script as a continuation. Do not restart with a first-contact introduction when
the context shows a prior conversation.

Generate all user-facing call script content in French.
Use professional, natural French.
Do not use English unless the prospect context explicitly requires another language.
The CRM user may work in any industry, and the target contact may have any
professional role. Never assume the target prospect is looking for CRM software,
sales software, prospecting software or marketing software unless verified CRM
context explicitly supports that assumption.
If the prospect's need is not known, focus the script on understanding current
priorities rather than asserting a problem.

Include:
- objective
- opening
- hook
- discovery questions
- value proposition
- possible objections
- suggested objection responses
- call to action
- closing

Use only verified CRM data.
Do not invent a prospect need, problem, budget, project, technology used,
company news, social post or previous conversation.
If no objection is known, possible objections may be general sales possibilities,
but they must not be presented as facts already expressed by the prospect.

Return only the requested structured JSON output.
""".strip()


SOCIAL_MESSAGE_GENERATION_PROMPT = """
You are an expert B2B sales message writer.

Generate a short personalized message for the selected social channel using only
verified CRM data and the provided engagement plan.
If the CRM context contains previous interactions or engagement_memory, reflect
that continuity when relevant.

Generate all user-facing social message content in French.
Use professional, natural French.
Do not use English unless the prospect context explicitly requires another language.
If no real first name is available, use "Bonjour," instead of inventing or writing
"Bonjour Contact".
The CRM user may work in any industry, and the target contact may have any
professional role. Never assume the target prospect is looking for CRM software,
sales software, prospecting software or marketing software unless verified CRM
context explicitly supports that assumption.
If the prospect's need is not known, stay general and ask to understand current
priorities.

Channel style:
- linkedin: professional, B2B, short, direct
- facebook: conversational, natural, professional
- instagram: short, light, direct, still professional for B2B prospects

The message will be manually copied and sent by a salesperson.
Do not reference browser automation.
Do not mention integrations.
Do not claim the message has already been sent.

Do not invent a prospect need, problem, budget, project, technology used,
company news, social post or previous conversation.
Do not write "I saw your recent post" unless a real post is explicitly present
in the CRM context.

Return only the requested structured JSON output.
""".strip()


EMAIL_SCHEMA_HINT = """
{
  "content_required": true,
  "channel": "email",
  "content_type": "email",
  "reason": "short reason",
  "email": {
    "subject": "email subject",
    "body": "email body",
    "tone": "professional",
    "objective": "start_conversation"
  },
  "call_script": null,
  "social_message": null
}
""".strip()


CALL_SCRIPT_SCHEMA_HINT = """
{
  "content_required": true,
  "channel": "phone",
  "content_type": "call_script",
  "reason": "short reason",
  "email": null,
  "call_script": {
    "call_objective": "call objective",
    "opening": "opening sentence",
    "hook": "contextual hook",
    "discovery_questions": ["question 1", "question 2"],
    "value_proposition": "short value proposition",
    "possible_objections": [
      {
        "objection": "possible objection",
        "suggested_response": "suggested response"
      }
    ],
    "call_to_action": "next step",
    "closing": "closing sentence"
  },
  "social_message": null
}
""".strip()


SOCIAL_MESSAGE_SCHEMA_HINT = """
{
  "content_required": true,
  "channel": "linkedin | facebook | instagram",
  "content_type": "social_message",
  "reason": "short reason",
  "email": null,
  "call_script": null,
  "social_message": {
    "channel": "linkedin | facebook | instagram",
    "message": "short message",
    "tone": "professional",
    "objective": "start_conversation",
    "execution_mode": "manual"
  }
}
""".strip()


def _json(data) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2, default=str)


def _model_dump(model) -> dict:
    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()


class EngagementContentGenerator:
    """
    Generate channel-specific content from an already validated strategy plan.

    This class does not choose strategy, change channels, send messages, write to
    the database or analyze prospect replies.
    """

    def __init__(self, model=None, channel_resolver=None):
        self.model = model
        self.channel_resolver = channel_resolver or ChannelResolver()

    def generate(self, context: dict, plan: EngagementStrategyPlan | dict) -> GeneratedEngagementContent:
        plan = self._coerce_plan(plan)

        if plan.should_wait or plan.strategy == "WAIT":
            return GeneratedEngagementContent(
                content_required=False,
                channel=None,
                content_type=None,
                reason="Strategy is WAIT",
            )

        if plan.strategy == "STOP_ENGAGEMENT":
            return GeneratedEngagementContent(
                content_required=False,
                channel=None,
                content_type=None,
                reason="Strategy is STOP_ENGAGEMENT",
            )

        if not plan.primary_channel:
            raise EngagementContentGenerationUnavailable("primary_channel_required")

        self._validate_primary_channel_available(context, plan.primary_channel)

        model = self.model or get_gemini_model(max_output_tokens=2048, temperature=0.15, top_p=0.75)
        prompt = self._build_prompt(context=context, plan=plan)

        try:
            data = self._call_gemini(model, prompt)
            return self._validate_content(data, plan)
        except Exception as first_error:
            logger.warning("[content-generator] initial content invalid: %s", first_error)
            try:
                correction_prompt = self._build_correction_prompt(
                    context=context,
                    plan=plan,
                    invalid_payload=locals().get("data", None),
                    error=first_error,
                )
                corrected_data = self._call_gemini(model, correction_prompt)
                return self._validate_content(corrected_data, plan)
            except Exception as correction_error:
                logger.warning("[content-generator] content generation unavailable: %s", correction_error)
                raise EngagementContentGenerationUnavailable(
                    "engagement_content_generation_unavailable"
                ) from correction_error

    def _coerce_plan(self, plan: EngagementStrategyPlan | dict) -> EngagementStrategyPlan:
        if isinstance(plan, EngagementStrategyPlan):
            return plan
        return _model_validate(EngagementStrategyPlan, plan)

    def _validate_primary_channel_available(self, context: dict, primary_channel: str):
        channels = self.channel_resolver.resolve(context or {})
        if not (channels.get(primary_channel) or {}).get("available"):
            raise EngagementContentGenerationUnavailable("primary_channel_unavailable")

    def _call_gemini(self, model, prompt: str) -> dict:
        response = generate_with_retry(model, prompt, max_retries=2, wait_seconds=30, log_prefix="content-generator")
        if not response or not getattr(response, "text", None):
            raise ValueError("empty_gemini_response")
        return extract_json(response.text)

    def _validate_content(self, data: dict, plan: EngagementStrategyPlan) -> GeneratedEngagementContent:
        content = _model_validate(GeneratedEngagementContent, data)

        if not content.content_required:
            raise ValueError("content_required must be true for active engagement content")

        if content.channel != plan.primary_channel:
            raise ValueError("content channel must match plan.primary_channel")

        expected_type = self._content_type_for_channel(plan.primary_channel)
        if content.content_type != expected_type:
            raise ValueError("content_type does not match plan.primary_channel")

        active = [bool(content.email), bool(content.call_script), bool(content.social_message)]
        if sum(active) != 1:
            raise ValueError("exactly one content payload must be active")

        if plan.primary_channel == "email":
            if not content.email or not content.email.subject.strip() or not content.email.body.strip():
                raise ValueError("email subject and body are required")
            if content.call_script or content.social_message:
                raise ValueError("email content cannot include call_script or social_message")
            return content

        if plan.primary_channel == "phone":
            script = content.call_script
            if not script or not script.opening.strip() or not script.discovery_questions or not script.call_to_action.strip():
                raise ValueError("call script opening, discovery_questions and call_to_action are required")
            if content.email or content.social_message:
                raise ValueError("phone content cannot include email or social_message")
            return content

        if plan.primary_channel in SOCIAL_CHANNELS:
            social = content.social_message
            if not social or social.channel != plan.primary_channel or not social.message.strip():
                raise ValueError("social message must match selected channel and include a message")
            if social.execution_mode != "manual":
                raise ValueError("social messages must remain manual")
            if content.email or content.call_script:
                raise ValueError("social content cannot include email or call_script")
            return content

        raise ValueError("unsupported primary_channel")

    def _content_type_for_channel(self, channel: str) -> str:
        if channel == "email":
            return "email"
        if channel == "phone":
            return "call_script"
        if channel in SOCIAL_CHANNELS:
            return "social_message"
        raise ValueError("unsupported primary_channel")

    def _build_prompt(self, context: dict, plan: EngagementStrategyPlan) -> str:
        if plan.primary_channel == "email":
            system_prompt = EMAIL_GENERATION_PROMPT
            schema_hint = EMAIL_SCHEMA_HINT
        elif plan.primary_channel == "phone":
            system_prompt = CALL_SCRIPT_GENERATION_PROMPT
            schema_hint = CALL_SCRIPT_SCHEMA_HINT
        elif plan.primary_channel in SOCIAL_CHANNELS:
            system_prompt = SOCIAL_MESSAGE_GENERATION_PROMPT
            schema_hint = SOCIAL_MESSAGE_SCHEMA_HINT
        else:
            raise ValueError("unsupported primary_channel")

        return f"""
{system_prompt}

VERIFIED CRM CONTEXT:
{_json(context or {})}

ENGAGEMENT PLAN:
{_json(_model_dump(plan))}

Selected channel:
{plan.primary_channel}

Expected JSON schema:
{schema_hint}
""".strip()

    def _build_correction_prompt(self, context: dict, plan: EngagementStrategyPlan, invalid_payload, error: Exception) -> str:
        return f"""
The previous generated content was invalid.
Return one corrected JSON object only. Do not add markdown or explanations.

Validation error:
{str(error)}

Invalid payload:
{_json(invalid_payload)}

VERIFIED CRM CONTEXT:
{_json(context or {})}

ENGAGEMENT PLAN:
{_json(_model_dump(plan))}

Expected JSON schema:
{self._schema_hint_for_channel(plan.primary_channel)}
""".strip()

    def _schema_hint_for_channel(self, channel: str) -> str:
        if channel == "email":
            return EMAIL_SCHEMA_HINT
        if channel == "phone":
            return CALL_SCRIPT_SCHEMA_HINT
        if channel in SOCIAL_CHANNELS:
            return SOCIAL_MESSAGE_SCHEMA_HINT
        raise ValueError("unsupported primary_channel")
