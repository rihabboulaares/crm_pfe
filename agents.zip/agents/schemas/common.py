from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, Field, HttpUrl, field_validator


ContactKind = Literal["email", "phone", "facebook", "instagram", "linkedin", "website", "contact_form"]
AgentType = Literal[
    "orchestrator",
    "intent",
    "planning",
    "search",
    "enrichment",
    "scraping",
    "validation",
    "qualification",
    "crm_import",
]


class LeadContact(BaseModel):
    kind: ContactKind
    value: str
    source: str | None = None
    verified: bool = False


class LeadSource(BaseModel):
    name: str
    url: str | None = None
    confidence: float = 0.5
    data: dict[str, Any] = Field(default_factory=dict)


class Lead(BaseModel):
    id: str | None = None
    name: str
    target_type: str = "company"
    industry: str | None = None
    category: str | None = None
    description: str | None = None
    country: str | None = None
    city: str | None = None
    address: str | None = None
    phone: str | None = None
    email: str | None = None
    website: str | None = None
    facebook: str | None = None
    instagram: str | None = None
    linkedin: str | None = None
    contact_form: str | None = None
    contacts: list[LeadContact] = Field(default_factory=list)
    sources: list[str] = Field(default_factory=list)
    source_details: list[LeadSource] = Field(default_factory=list)
    score: int = 0
    status: str = "raw"
    confidence: float = 0
    validation_reasons: list[str] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)

    @field_validator("name", mode="before")
    @classmethod
    def require_name(cls, value):
        value = str(value or "").strip()
        if not value:
            raise ValueError("Lead name is required")
        return value[:255]


class IntentCriteria(BaseModel):
    raw_query: str
    target_type: str = "company"
    industry: str | None = None
    location: str | None = None
    country: str | None = "Tunisie"
    max_leads: int = Field(default=10, ge=1, le=50)
    required_contact_count: int = Field(default=1, ge=1, le=5)
    preferred_sources: list[str] = Field(default_factory=lambda: ["google_maps", "serper", "website"])


class SearchQuery(BaseModel):
    tool: str
    query: str
    limit: int = Field(default=10, ge=1, le=50)


class SearchPlan(BaseModel):
    queries: list[SearchQuery] = Field(default_factory=list)
    target_count: int = Field(default=10, ge=1, le=50)
    max_iterations: int = Field(default=10, ge=1, le=20)


class ValidationResult(BaseModel):
    valid: bool
    confidence: float = Field(default=0, ge=0, le=1)
    verified_contacts: list[str] = Field(default_factory=list)
    reasons: list[str] = Field(default_factory=list)


class QualificationResult(BaseModel):
    score: int = Field(default=0, ge=0, le=100)
    status: str
    priority: str
    explanation: str = ""


class AgentTask(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid4()))
    agent_type: AgentType
    action: str
    input: dict[str, Any] = Field(default_factory=dict)
    execution_id: int | None = None


class AgentResult(BaseModel):
    task_id: str
    agent_type: AgentType
    status: str = "completed"
    success: bool = True
    results: Any = None
    errors: list[str] = Field(default_factory=list)
    metrics: dict[str, Any] = Field(default_factory=dict)


class ProspectionState(BaseModel):
    execution_id: str
    user_id: int
    raw_query: str
    intent: dict[str, Any] | None = None
    plan: dict[str, Any] | None = None
    raw_leads: list[Lead] = Field(default_factory=list)
    enriched_leads: list[Lead] = Field(default_factory=list)
    validated_leads: list[Lead] = Field(default_factory=list)
    rejected_leads: list[Lead] = Field(default_factory=list)
    imported_leads: list[Lead] = Field(default_factory=list)
    current_step: str = "created"
    progress: int = 0
    iteration: int = 0
    max_iterations: int = 10
    target_count: int = 10
    errors: list[str] = Field(default_factory=list)
