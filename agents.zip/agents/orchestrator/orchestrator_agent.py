from time import perf_counter

from agents.prospection_agents import (
    CRMImportAgent,
    EnrichmentAgent,
    IntentAnalysisAgent,
    QualificationAgent,
    SearchAgent,
    SearchPlanningAgent,
    ValidationAgent,
)
from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask


class ProspectionOrchestratorAgent(BaseAgent):
    agent_name = "orchestrator"

    def __init__(self, gemini_service=None, tools=None, execution_service=None):
        super().__init__(gemini_service=gemini_service, tools=tools, execution_service=execution_service)
        kwargs = {
            "gemini_service": gemini_service,
            "tools": tools,
            "execution_service": execution_service,
        }
        self.intent_agent = IntentAnalysisAgent(**kwargs)
        self.planning_agent = SearchPlanningAgent(**kwargs)
        self.search_agent = SearchAgent(**kwargs)
        self.enrichment_agent = EnrichmentAgent(**kwargs)
        self.validation_agent = ValidationAgent(**kwargs)
        self.qualification_agent = QualificationAgent(**kwargs)
        self.crm_import_agent = CRMImportAgent(**kwargs)

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        query = str(task.input.get("query") or "").strip()
        max_iterations = min(int(task.input.get("max_iterations") or 10), 20)
        auto_import = bool(task.input.get("auto_import"))
        user_id = task.input.get("user_id")
        company_id = task.input.get("company_id")

        await self.log(task.execution_id, "orchestrator", "Demarrage orchestrateur", {"query": query})
        errors = []

        intent_result = await self.intent_agent.run(
            AgentTask(agent_type="intent", action="analyze", input={"query": query}, execution_id=task.execution_id)
        )
        intent = intent_result.results

        if task.input.get("max_leads"):
            intent["max_leads"] = min(int(task.input.get("max_leads")), 50)
        if task.input.get("sources"):
            intent["preferred_sources"] = task.input.get("sources")

        plan_result = await self.planning_agent.run(
            AgentTask(agent_type="planning", action="plan", input={"intent": intent}, execution_id=task.execution_id)
        )
        plan = plan_result.results

        raw_leads = []
        enriched_leads = []
        validated_leads = []
        rejected_leads = []
        qualified_leads = []
        import_result = {}

        for iteration in range(max_iterations):
            await self.log(task.execution_id, "iteration", f"Iteration {iteration + 1}/{max_iterations}")

            search_result = await self.search_agent.run(
                AgentTask(agent_type="search", action="search_businesses", input={"plan": plan}, execution_id=task.execution_id)
            )
            raw_leads = search_result.results.get("leads", [])
            errors.extend(search_result.errors)

            enrich_result = await self.enrichment_agent.run(
                AgentTask(agent_type="enrichment", action="enrich", input={"leads": raw_leads}, execution_id=task.execution_id)
            )
            enriched_leads = enrich_result.results.get("leads", [])
            errors.extend(enrich_result.errors)

            validation_result = await self.validation_agent.run(
                AgentTask(
                    agent_type="validation",
                    action="validate",
                    input={"leads": enriched_leads, "intent": intent},
                    execution_id=task.execution_id,
                )
            )
            validated_leads = validation_result.results.get("validated_leads", [])
            rejected_leads = validation_result.results.get("rejected_leads", [])

            if len(validated_leads) >= int(intent.get("max_leads") or plan.get("target_count") or 10):
                break

            if iteration == max_iterations - 1:
                break

        qualify_result = await self.qualification_agent.run(
            AgentTask(agent_type="qualification", action="qualify", input={"leads": validated_leads}, execution_id=task.execution_id)
        )
        qualified_leads = qualify_result.results.get("leads", [])

        target_count = int(intent.get("max_leads") or plan.get("target_count") or 10)
        selected = qualified_leads[:target_count]

        import_agent_result = await self.crm_import_agent.run(
            AgentTask(
                agent_type="crm_import",
                action="prepare_or_import",
                input={
                    "leads": selected,
                    "auto_import": auto_import,
                    "user_id": user_id,
                    "company_id": company_id,
                },
                execution_id=task.execution_id,
            )
        )
        import_result = import_agent_result.results
        errors.extend(import_agent_result.errors)

        payload = {
            "intent": intent,
            "plan": plan,
            "raw_leads": raw_leads,
            "enriched_leads": enriched_leads,
            "validated_leads": validated_leads,
            "rejected_leads": rejected_leads,
            "qualified_leads": selected,
            "import_result": import_result,
            "counts": {
                "raw": len(raw_leads),
                "enriched": len(enriched_leads),
                "validated": len(validated_leads),
                "rejected": len(rejected_leads),
                "qualified": len(selected),
            },
            "errors": errors,
        }
        return self.result(task, results=payload, errors=errors, start_time=started, status="partial" if errors else "completed")
