from django.conf import settings
from django.db import models


class AgentExecution(models.Model):
    STATUS_CHOICES = [
        ("pending", "Pending"),
        ("running", "Running"),
        ("completed", "Completed"),
        ("partial", "Partial"),
        ("failed", "Failed"),
        ("cancelled", "Cancelled"),
    ]

    AGENT_TYPE_CHOICES = [
        ("orchestrator", "Orchestrator"),
        ("intent", "Intent"),
        ("planning", "Planning"),
        ("search", "Search"),
        ("enrichment", "Enrichment"),
        ("scraping", "Scraping"),
        ("validation", "Validation"),
        ("qualification", "Qualification"),
        ("crm_import", "CRM import"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="new_agent_executions",
    )
    company = models.ForeignKey(
        "users.Company",
        on_delete=models.CASCADE,
        related_name="new_agent_executions",
        null=True,
        blank=True,
    )
    agent_type = models.CharField(max_length=32, choices=AGENT_TYPE_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    input_data = models.JSONField(default=dict, blank=True)
    result_data = models.JSONField(default=dict, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    progress = models.PositiveSmallIntegerField(default=0)
    current_step = models.CharField(max_length=120, blank=True, default="")
    error_message = models.TextField(blank=True, default="")
    metrics = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["user", "agent_type", "status"]),
            models.Index(fields=["company", "created_at"]),
        ]

    def __str__(self):
        return f"{self.agent_type} #{self.pk} ({self.status})"


class AgentExecutionLog(models.Model):
    LEVEL_CHOICES = [
        ("debug", "Debug"),
        ("info", "Info"),
        ("warning", "Warning"),
        ("error", "Error"),
    ]

    execution = models.ForeignKey(
        AgentExecution,
        on_delete=models.CASCADE,
        related_name="logs",
    )
    level = models.CharField(max_length=16, choices=LEVEL_CHOICES, default="info")
    step = models.CharField(max_length=120, blank=True, default="")
    message = models.TextField()
    data = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]
        indexes = [models.Index(fields=["execution", "created_at"])]

    def __str__(self):
        return f"{self.execution_id}:{self.step}"
