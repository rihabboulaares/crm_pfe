from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("users", "0008_alter_invitation_role_alter_user_role"),
    ]

    operations = [
        migrations.CreateModel(
            name="AgentExecution",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("agent_type", models.CharField(choices=[("orchestrator", "Orchestrator"), ("intent", "Intent"), ("planning", "Planning"), ("search", "Search"), ("enrichment", "Enrichment"), ("scraping", "Scraping"), ("validation", "Validation"), ("qualification", "Qualification"), ("crm_import", "CRM import")], max_length=32)),
                ("status", models.CharField(choices=[("pending", "Pending"), ("running", "Running"), ("completed", "Completed"), ("partial", "Partial"), ("failed", "Failed"), ("cancelled", "Cancelled")], default="pending", max_length=20)),
                ("input_data", models.JSONField(blank=True, default=dict)),
                ("result_data", models.JSONField(blank=True, default=dict)),
                ("started_at", models.DateTimeField(blank=True, null=True)),
                ("completed_at", models.DateTimeField(blank=True, null=True)),
                ("progress", models.PositiveSmallIntegerField(default=0)),
                ("current_step", models.CharField(blank=True, default="", max_length=120)),
                ("error_message", models.TextField(blank=True, default="")),
                ("metrics", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("company", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="new_agent_executions", to="users.company")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="new_agent_executions", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="AgentExecutionLog",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("level", models.CharField(choices=[("debug", "Debug"), ("info", "Info"), ("warning", "Warning"), ("error", "Error")], default="info", max_length=16)),
                ("step", models.CharField(blank=True, default="", max_length=120)),
                ("message", models.TextField()),
                ("data", models.JSONField(blank=True, default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("execution", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="logs", to="agents.agentexecution")),
            ],
            options={"ordering": ["created_at"]},
        ),
        migrations.AddIndex(
            model_name="agentexecution",
            index=models.Index(fields=["user", "agent_type", "status"], name="agents_agen_user_id_775d3e_idx"),
        ),
        migrations.AddIndex(
            model_name="agentexecution",
            index=models.Index(fields=["company", "created_at"], name="agents_agen_company_c8d6a1_idx"),
        ),
        migrations.AddIndex(
            model_name="agentexecutionlog",
            index=models.Index(fields=["execution", "created_at"], name="agents_agen_executi_3e6e6f_idx"),
        ),
    ]
