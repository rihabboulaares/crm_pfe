from asgiref.sync import async_to_sync
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from agents.api.serializers import AgentExecutionSerializer
from agents.models import AgentExecution
from agents.orchestrator import ProspectionOrchestratorAgent
from agents.prospection_agents import (
    CRMImportAgent,
    EnrichmentAgent,
    QualificationAgent,
    ScrapingAgent,
    SearchAgent,
    ValidationAgent,
)
from agents.prospection_agents.intent_agent import IntentAnalysisAgent
from agents.prospection_agents.planning_agent import SearchPlanningAgent
from agents.schemas import AgentTask
from agents.services.execution_service import ExecutionService
from agents.services.gemini_service import GeminiService
from agents.tools import build_tools


AGENT_CLASSES = {
    "orchestrator": ProspectionOrchestratorAgent,
    "intent": IntentAnalysisAgent,
    "planning": SearchPlanningAgent,
    "search": SearchAgent,
    "enrichment": EnrichmentAgent,
    "scraping": ScrapingAgent,
    "validation": ValidationAgent,
    "qualification": QualificationAgent,
    "crm_import": CRMImportAgent,
}


def get_user_company(user):
    return getattr(user, "company", None)


class AgentRunView(APIView):
    def post(self, request, agent_type):
        if agent_type not in AGENT_CLASSES:
            return Response({"success": False, "message": "Agent inconnu"}, status=status.HTTP_404_NOT_FOUND)

        company = get_user_company(request.user)
        if not company:
            return Response({"success": False, "message": "Aucune societe associee"}, status=status.HTTP_403_FORBIDDEN)

        payload = dict(request.data or {})
        payload["user_id"] = request.user.id
        payload["company_id"] = company.id

        execution_service = ExecutionService()
        execution = async_to_sync(execution_service.create_execution)(
            user=request.user,
            company=company,
            agent_type=agent_type,
            input_data=payload,
        )

        agent = AGENT_CLASSES[agent_type](
            gemini_service=GeminiService(),
            tools=build_tools(),
            execution_service=execution_service,
        )

        try:
            result = async_to_sync(agent.run)(
                AgentTask(
                    agent_type=agent_type,
                    action=payload.get("action") or "run",
                    input=payload,
                    execution_id=execution.id,
                )
            )
            result_data = result.model_dump()
            async_to_sync(execution_service.finish_execution)(
                execution_id=execution.id,
                status=result.status if result.status in {"completed", "partial", "failed"} else "completed",
                result_data=result_data,
                progress=100,
                current_step=result.status,
                error_message="; ".join(result.errors[:3]),
                metrics=result.metrics,
            )
            return Response({"success": result.success, "execution_id": execution.id, **result_data})
        except Exception as exc:
            async_to_sync(execution_service.finish_execution)(
                execution_id=execution.id,
                status="failed",
                result_data={},
                progress=100,
                current_step="failed",
                error_message=str(exc)[:500],
            )
            return Response(
                {"success": False, "execution_id": execution.id, "message": "Erreur agent", "details": str(exc)[:500]},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )


class AgentExecutionListView(APIView):
    def get(self, request):
        qs = AgentExecution.objects.filter(user=request.user).order_by("-created_at")
        agent_type = request.query_params.get("agent_type")
        if agent_type:
            qs = qs.filter(agent_type=agent_type)
        return Response(AgentExecutionSerializer(qs[:50], many=True).data)


class AgentExecutionDetailView(APIView):
    def get(self, request, pk):
        execution = AgentExecution.objects.filter(id=pk, user=request.user).first()
        if not execution:
            return Response({"success": False, "message": "Execution introuvable"}, status=status.HTTP_404_NOT_FOUND)
        return Response(AgentExecutionSerializer(execution).data)


class AgentExecutionRetryView(APIView):
    def post(self, request, pk):
        execution = AgentExecution.objects.filter(id=pk, user=request.user).first()
        if not execution:
            return Response({"success": False, "message": "Execution introuvable"}, status=status.HTTP_404_NOT_FOUND)
        view = AgentRunView()
        view.request = request
        request._full_data = execution.input_data
        return view.post(request, execution.agent_type)


class AgentExecutionCancelView(APIView):
    def post(self, request, pk):
        updated = AgentExecution.objects.filter(id=pk, user=request.user, status__in=["pending", "running"]).update(
            status="cancelled",
            current_step="cancelled",
            progress=100,
        )
        return Response({"success": bool(updated), "status": "cancelled" if updated else "unchanged"})
