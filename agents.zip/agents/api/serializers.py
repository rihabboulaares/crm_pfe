from rest_framework import serializers

from agents.models import AgentExecution, AgentExecutionLog


class AgentExecutionLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = AgentExecutionLog
        fields = ["id", "level", "step", "message", "data", "created_at"]


class AgentExecutionSerializer(serializers.ModelSerializer):
    logs = AgentExecutionLogSerializer(many=True, read_only=True)
    duration_seconds = serializers.SerializerMethodField()

    class Meta:
        model = AgentExecution
        fields = [
            "id",
            "agent_type",
            "status",
            "input_data",
            "result_data",
            "started_at",
            "completed_at",
            "progress",
            "current_step",
            "error_message",
            "metrics",
            "created_at",
            "updated_at",
            "duration_seconds",
            "logs",
        ]

    def get_duration_seconds(self, obj):
        if obj.started_at and obj.completed_at:
            return round((obj.completed_at - obj.started_at).total_seconds(), 2)
        return None
