from django.contrib import admin

from .models import AgentExecution, AgentExecutionLog


class AgentExecutionLogInline(admin.TabularInline):
    model = AgentExecutionLog
    extra = 0
    readonly_fields = ("level", "step", "message", "data", "created_at")
    can_delete = False


@admin.register(AgentExecution)
class AgentExecutionAdmin(admin.ModelAdmin):
    list_display = ("id", "agent_type", "status", "user", "company", "progress", "created_at")
    list_filter = ("agent_type", "status", "created_at")
    search_fields = ("user__email", "user__username", "current_step", "error_message")
    readonly_fields = ("created_at", "updated_at")
    inlines = [AgentExecutionLogInline]


@admin.register(AgentExecutionLog)
class AgentExecutionLogAdmin(admin.ModelAdmin):
    list_display = ("id", "execution", "level", "step", "created_at")
    list_filter = ("level", "step", "created_at")
