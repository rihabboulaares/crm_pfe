import json
import os
import re
from typing import Type

from google import genai
from google.genai import types
from pydantic import BaseModel


class GeminiService:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        self.client = genai.Client(api_key=api_key) if api_key else None
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    def available(self) -> bool:
        return self.client is not None

    def generate_json(self, prompt: str, schema: Type[BaseModel] | None = None) -> dict:
        if not self.client:
            return {"success": False, "data": None, "error": "Gemini API key missing"}

        config_kwargs = {"response_mime_type": "application/json"}
        if schema is not None:
            config_kwargs["response_schema"] = schema

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=types.GenerateContentConfig(**config_kwargs),
            )
            text = getattr(response, "text", "") or "{}"
            data = self._parse_json(text)
            if schema is not None:
                data = schema.model_validate(data).model_dump()
            return {"success": True, "data": data, "error": None}
        except Exception as exc:
            return {"success": False, "data": None, "error": str(exc)[:500]}

    def _parse_json(self, text: str) -> dict:
        value = str(text or "").strip()
        if value.startswith("```"):
            value = re.sub(r"^```(?:json)?", "", value, flags=re.I).strip()
            value = re.sub(r"```$", "", value).strip()
        return json.loads(value or "{}")
