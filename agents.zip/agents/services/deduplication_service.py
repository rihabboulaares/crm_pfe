from difflib import SequenceMatcher

from agents.schemas import Lead
from agents.services.normalization_service import domain_from_url


def normalize_text(value: str | None) -> str:
    return " ".join(str(value or "").lower().strip().split())


def normalize_phone(value: str | None) -> str:
    return "".join(ch for ch in str(value or "") if ch.isdigit() or ch == "+")


class DeduplicationService:
    def dedupe(self, leads: list[Lead]) -> tuple[list[Lead], list[dict]]:
        unique: list[Lead] = []
        duplicates: list[dict] = []

        for lead in leads:
            match = self.find_duplicate(unique, lead)
            if match:
                duplicates.append(match)
                continue
            unique.append(lead)

        return unique, duplicates

    def find_duplicate(self, existing: list[Lead], lead: Lead) -> dict | None:
        for candidate in existing:
            fields = []
            if lead.email and candidate.email and lead.email.lower() == candidate.email.lower():
                fields.append("email")
            if lead.phone and candidate.phone and normalize_phone(lead.phone) == normalize_phone(candidate.phone):
                fields.append("phone")
            if lead.website and candidate.website and domain_from_url(lead.website) == domain_from_url(candidate.website):
                fields.append("website_domain")
            for field in ["facebook", "instagram", "linkedin"]:
                if getattr(lead, field) and getattr(candidate, field) and getattr(lead, field) == getattr(candidate, field):
                    fields.append(field)

            name_ratio = SequenceMatcher(None, normalize_text(lead.name), normalize_text(candidate.name)).ratio()
            same_city = normalize_text(lead.city) and normalize_text(lead.city) == normalize_text(candidate.city)
            if name_ratio >= 0.92 and same_city:
                fields.append("name_city")

            if fields:
                confidence = 0.95 if any(f in fields for f in ["email", "phone", "website_domain"]) else 0.82
                return {
                    "is_duplicate": True,
                    "matched_lead_id": candidate.id or candidate.name,
                    "confidence": confidence,
                    "matched_fields": fields,
                }
        return None
