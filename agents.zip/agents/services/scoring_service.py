from agents.schemas import Lead, QualificationResult
from agents.services.normalization_service import contact_fields


class ScoringService:
    def score(self, lead: Lead, target_match: bool = True, coherent: bool = True) -> QualificationResult:
        points = 0
        if lead.email:
            points += 20
        if lead.phone:
            points += 15
        if lead.website:
            points += 10
        if lead.facebook:
            points += 10
        if lead.instagram:
            points += 10
        if lead.linkedin:
            points += 5
        if lead.raw.get("meta_ads_active"):
            points += 10
        if target_match:
            points += 15
        if coherent:
            points += 5

        points = min(points, 100)
        if points >= 80:
            status, priority = "qualified", "high"
        elif points >= 60:
            status, priority = "qualified", "medium"
        elif points >= 40:
            status, priority = "needs_enrichment", "low"
        else:
            status, priority = "rejected", "low"

        contacts = ", ".join(contact_fields(lead)) or "aucun contact"
        return QualificationResult(
            score=points,
            status=status,
            priority=priority,
            explanation=f"Score calcule avec les contacts disponibles: {contacts}.",
        )
