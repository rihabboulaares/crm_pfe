from asgiref.sync import sync_to_async
from django.utils import timezone

from agents.models import AgentExecution, AgentExecutionLog


class ExecutionService:
    @sync_to_async
    def create_execution(self, *, user, company, agent_type: str, input_data: dict) -> AgentExecution:
        return AgentExecution.objects.create(
            user=user,
            company=company,
            agent_type=agent_type,
            status="running",
            input_data=input_data or {},
            started_at=timezone.now(),
            current_step="started",
        )

    @sync_to_async
    def add_log(self, *, execution_id: int, step: str, message: str, data=None, level: str = "info"):
        return AgentExecutionLog.objects.create(
            execution_id=execution_id,
            level=level,
            step=step,
            message=message,
            data=data or {},
        )

    @sync_to_async
    def finish_execution(
        self,
        *,
        execution_id: int,
        status: str,
        result_data: dict,
        progress: int = 100,
        current_step: str = "completed",
        error_message: str = "",
        metrics: dict | None = None,
    ):
        execution = AgentExecution.objects.get(id=execution_id)
        execution.status = status
        execution.result_data = result_data or {}
        execution.progress = progress
        execution.current_step = current_step
        execution.error_message = error_message or ""
        execution.metrics = metrics or {}
        execution.completed_at = timezone.now()
        execution.save(
            update_fields=[
                "status",
                "result_data",
                "progress",
                "current_step",
                "error_message",
                "metrics",
                "completed_at",
                "updated_at",
            ]
        )
        return execution
