from urllib.parse import urlparse

from agents.schemas import Lead


def normalize_source_lead(item: dict, source: str) -> Lead | None:
    name = (
        item.get("name")
        or item.get("company_name")
        or item.get("full_name")
        or item.get("title")
    )
    if not name:
        return None

    return Lead(
        name=name,
        target_type=item.get("lead_type") or "company",
        industry=item.get("industry"),
        category=item.get("category") or item.get("primaryType"),
        description=item.get("description") or item.get("content"),
        country=item.get("country") or "Tunisie",
        city=item.get("city"),
        address=item.get("address"),
        phone=item.get("phone"),
        email=item.get("email"),
        website=item.get("website"),
        facebook=item.get("facebook") or item.get("facebook_url"),
        instagram=item.get("instagram") or item.get("instagram_url"),
        linkedin=item.get("linkedin") or item.get("linkedin_url"),
        sources=list(dict.fromkeys([source, item.get("source") or ""])),
        raw=item,
    )


def contact_fields(lead: Lead) -> list[str]:
    fields = []
    for field in ["email", "phone", "facebook", "instagram", "linkedin", "website", "contact_form"]:
        if getattr(lead, field, None):
            fields.append(field)
    return fields


def domain_from_url(url: str | None) -> str:
    if not url:
        return ""
    parsed = urlparse(str(url).strip())
    return (parsed.netloc or parsed.path).lower().replace("www.", "").strip("/")
