from time import perf_counter

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, SearchPlan
from agents.services.deduplication_service import DeduplicationService
from agents.services.normalization_service import normalize_source_lead


class SearchAgent(BaseAgent):
    agent_name = "search"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        plan = SearchPlan.model_validate(task.input.get("plan") or task.input)
        await self.log(task.execution_id, "search", "Recherche de prospects bruts")

        leads = []
        errors = []
        for query in plan.queries[: plan.max_iterations]:
            tool_key = self._tool_key(query.tool)
            tool = self.tools.get(tool_key)
            if not tool:
                errors.append(f"Outil indisponible: {query.tool}")
                continue
            try:
                if tool_key == "serper":
                    platform = self._platform(query.tool)
                    raw_results = await tool.run(query.query, platform=platform)
                else:
                    raw_results = await tool.run(query.query)
                for item in (raw_results or [])[: query.limit]:
                    lead = normalize_source_lead(item, query.tool)
                    if lead:
                        leads.append(lead)
            except Exception as exc:
                errors.append(f"{query.tool}: {str(exc)[:200]}")

        unique, duplicates = DeduplicationService().dedupe(leads)
        payload = {
            "leads": [lead.model_dump() for lead in unique[: plan.target_count]],
            "raw_count": len(leads),
            "duplicates": duplicates,
            "duplicates_count": len(duplicates),
        }
        return self.result(task, results=payload, errors=errors, start_time=started)

    def _tool_key(self, name: str) -> str:
        if name in {"facebook", "instagram", "linkedin", "serper"}:
            return "serper"
        if name == "google_maps":
            return "maps"
        return name

    def _platform(self, name: str) -> str:
        if name in {"facebook", "instagram", "linkedin"}:
            return name
        return "general"
