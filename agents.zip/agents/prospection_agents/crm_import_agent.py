from time import perf_counter

from asgiref.sync import sync_to_async

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, Lead


class CRMImportAgent(BaseAgent):
    agent_name = "crm_import"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        leads = [Lead.model_validate(item) for item in task.input.get("leads", [])]
        auto_import = bool(task.input.get("auto_import"))
        await self.log(task.execution_id, "crm_import", "Preparation import CRM", {"count": len(leads), "auto": auto_import})
        if not auto_import:
            return self.result(
                task,
                results={"pending_import": [lead.model_dump() for lead in leads], "imported": [], "message": "Validation commerciale requise avant import."},
                start_time=started,
            )

        imported = []
        errors = []
        for lead in leads:
            try:
                imported.append(await self._save_lead(lead, task.input.get("user_id"), task.input.get("company_id")))
            except Exception as exc:
                errors.append(f"{lead.name}: {str(exc)[:200]}")

        return self.result(task, results={"imported": imported, "pending_import": []}, errors=errors, start_time=started)

    @sync_to_async
    def _save_lead(self, lead: Lead, user_id: int, company_id: int):
        from agentProspection.crm.importer import save_result_to_crm

        payload = {
            "company_name": lead.name,
            "lead_type": lead.target_type,
            "industry": lead.industry or lead.category,
            "phone": lead.phone,
            "email": lead.email,
            "city": lead.city,
            "country": lead.country,
            "address": lead.address,
            "website": lead.website,
            "facebook_url": lead.facebook,
            "instagram_url": lead.instagram,
            "linkedin_url": lead.linkedin,
            "source": "new_prospection_agents",
            "evaluation": "hot" if lead.score >= 80 else "warm" if lead.score >= 60 else "cold",
            "raison_score": "; ".join(lead.validation_reasons),
        }
        prospect = save_result_to_crm(payload, user_id, company_id)
        return {"lead": lead.name, "prospect_id": getattr(prospect, "id", None)}
