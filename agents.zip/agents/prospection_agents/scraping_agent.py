from time import perf_counter

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask
from agents.services.normalization_service import normalize_source_lead


class ScrapingAgent(BaseAgent):
    agent_name = "scraping"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        url = str(task.input.get("url") or "").strip()
        await self.log(task.execution_id, "scraping", "Analyse du site web", {"url": url})
        if not url:
            return self.result(task, errors=["URL obligatoire"], start_time=started, status="failed")

        scraper = self.tools.get("website_scraper")
        if not scraper:
            return self.result(task, errors=["Outil website_scraper indisponible"], start_time=started, status="failed")

        try:
            raw = await scraper.run(url)
            lead = normalize_source_lead(raw, "website")
            result = {
                "method": "http_or_playwright_auto",
                "lead": lead.model_dump() if lead else None,
                "raw": raw,
                "pages_visited": 1,
                "errors": [raw.get("error")] if isinstance(raw, dict) and raw.get("error") else [],
            }
            return self.result(task, results=result, start_time=started)
        except Exception as exc:
            return self.result(task, errors=[str(exc)[:300]], start_time=started, status="failed")
