from time import perf_counter

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, Lead, ValidationResult
from agents.services.normalization_service import contact_fields


class ValidationAgent(BaseAgent):
    agent_name = "validation"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        leads = [Lead.model_validate(item) for item in task.input.get("leads", [])]
        await self.log(task.execution_id, "validation", "Validation des prospects", {"count": len(leads)})

        accepted = []
        rejected = []
        for lead in leads:
            validation = self.validate(lead, task.input.get("intent") or {})
            lead.confidence = validation.confidence
            lead.validation_reasons = validation.reasons
            lead.status = "validated" if validation.valid else "rejected"
            if validation.valid:
                accepted.append(lead)
            else:
                rejected.append(lead)

        return self.result(
            task,
            results={
                "validated_leads": [lead.model_dump() for lead in accepted],
                "rejected_leads": [lead.model_dump() for lead in rejected],
            },
            start_time=started,
        )

    def validate(self, lead: Lead, intent: dict) -> ValidationResult:
        contacts = contact_fields(lead)
        reasons = []
        if contacts:
            reasons.append("Au moins un moyen de contact est present.")
        else:
            reasons.append("Aucun moyen de contact verifie.")

        industry = str(intent.get("industry") or "").lower()
        if industry and industry in " ".join([lead.name, lead.industry or "", lead.category or "", lead.description or ""]).lower():
            reasons.append("Le secteur semble correspondre.")

        location = str(intent.get("location") or "").lower()
        if location and location in " ".join([lead.city or "", lead.address or ""]).lower():
            reasons.append("La localisation semble correspondre.")

        valid = bool(contacts)
        confidence = 0.65 + (0.1 * min(len(contacts), 3)) if valid else 0.2
        return ValidationResult(valid=valid, confidence=min(confidence, 0.95), verified_contacts=contacts, reasons=reasons)
