from abc import ABC, abstractmethod
from time import perf_counter

from agents.schemas import AgentResult, AgentTask


class BaseAgent(ABC):
    agent_name: str

    def __init__(self, gemini_service=None, tools=None, execution_service=None):
        self.gemini_service = gemini_service
        self.tools = tools or {}
        self.execution_service = execution_service

    @abstractmethod
    async def run(self, task: AgentTask) -> AgentResult:
        raise NotImplementedError

    async def log(self, execution_id, step, message, data=None, level="info"):
        if not self.execution_service or not execution_id:
            return None
        return await self.execution_service.add_log(
            execution_id=execution_id,
            step=step,
            message=message,
            data=data or {},
            level=level,
        )

    def result(self, task: AgentTask, *, results=None, errors=None, start_time=None, status="completed"):
        duration = round(perf_counter() - start_time, 2) if start_time else 0
        return AgentResult(
            task_id=task.task_id,
            agent_type=task.agent_type,
            status=status,
            success=not errors,
            results=results,
            errors=errors or [],
            metrics={"duration_seconds": duration},
        )
