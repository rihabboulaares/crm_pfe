import re
from time import perf_counter

from agents.prompts import INTENT_PROMPT
from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, IntentCriteria


class IntentAnalysisAgent(BaseAgent):
    agent_name = "intent"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        query = str(task.input.get("query") or task.input.get("raw_query") or "").strip()
        await self.log(task.execution_id, "intent", "Analyse de la demande utilisateur")

        prompt = INTENT_PROMPT.format(query=query)
        gemini = self.gemini_service.generate_json(prompt, IntentCriteria) if self.gemini_service else {}
        if gemini.get("success"):
            criteria = IntentCriteria.model_validate(gemini["data"])
        else:
            criteria = self._fallback(query)

        return self.result(task, results=criteria.model_dump(), start_time=started)

    def _fallback(self, query: str) -> IntentCriteria:
        max_leads = 10
        count_match = re.search(r"\b(\d{1,2})\b", query)
        if count_match:
            max_leads = min(int(count_match.group(1)), 50)

        q = query.lower()
        known_locations = ["tunis", "ariana", "sousse", "sfax", "nabeul", "bizerte", "la marsa"]
        known_industries = ["restaurant", "hotel", "hôtel", "cafe", "café", "dentiste", "avocat", "pharmacie", "clinique", "marketing"]
        location = next((item.title() for item in known_locations if item in q), None)
        industry = next((item for item in known_industries if item in q), None)
        sources = ["serper", "website", "facebook", "instagram", "linkedin"]
        if industry in {"restaurant", "hotel", "hôtel", "cafe", "café", "pharmacie", "clinique"}:
            sources.insert(0, "google_maps")
        return IntentCriteria(
            raw_query=query,
            industry=industry,
            location=location,
            max_leads=max_leads,
            preferred_sources=sources,
        )
