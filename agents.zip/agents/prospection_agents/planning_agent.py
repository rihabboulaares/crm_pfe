from time import perf_counter

from agents.prompts import PLANNING_PROMPT
from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, IntentCriteria, SearchPlan, SearchQuery


class SearchPlanningAgent(BaseAgent):
    agent_name = "planning"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        intent = IntentCriteria.model_validate(task.input.get("intent") or task.input)
        await self.log(task.execution_id, "planning", "Creation du plan de recherche")

        prompt = PLANNING_PROMPT.format(intent_json=intent.model_dump_json())
        gemini = self.gemini_service.generate_json(prompt, SearchPlan) if self.gemini_service else {}
        plan = SearchPlan.model_validate(gemini["data"]) if gemini.get("success") else self._fallback(intent)
        return self.result(task, results=plan.model_dump(), start_time=started)

    def _fallback(self, intent: IntentCriteria) -> SearchPlan:
        base = " ".join(x for x in [intent.industry, intent.location or intent.country] if x).strip()
        if not base:
            base = intent.raw_query

        queries = []
        if "google_maps" in intent.preferred_sources:
            queries.append(SearchQuery(tool="google_maps", query=base, limit=min(intent.max_leads + 10, 50)))
        queries.extend(
            [
                SearchQuery(tool="serper", query=f"{base} site officiel contact", limit=20),
                SearchQuery(tool="facebook", query=f"{base} Facebook", limit=20),
                SearchQuery(tool="instagram", query=f"{base} Instagram", limit=20),
                SearchQuery(tool="linkedin", query=f"{base} LinkedIn", limit=20),
            ]
        )
        return SearchPlan(queries=queries, target_count=intent.max_leads, max_iterations=10)
