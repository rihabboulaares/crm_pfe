from time import perf_counter

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, Lead
from agents.services.scoring_service import ScoringService


class QualificationAgent(BaseAgent):
    agent_name = "qualification"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        leads = [Lead.model_validate(item) for item in task.input.get("leads", [])]
        await self.log(task.execution_id, "qualification", "Qualification commerciale", {"count": len(leads)})
        scorer = ScoringService()
        qualified = []
        for lead in leads:
            result = scorer.score(lead)
            lead.score = result.score
            lead.status = result.status
            raw = dict(lead.raw or {})
            raw["qualification"] = result.model_dump()
            lead.raw = raw
            qualified.append(lead)

        qualified.sort(key=lambda item: item.score, reverse=True)
        return self.result(task, results={"leads": [lead.model_dump() for lead in qualified]}, start_time=started)
