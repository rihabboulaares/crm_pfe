from time import perf_counter

from agents.prospection_agents.base_agent import BaseAgent
from agents.schemas import AgentResult, AgentTask, Lead
from agents.services.normalization_service import normalize_source_lead


class EnrichmentAgent(BaseAgent):
    agent_name = "enrichment"

    async def run(self, task: AgentTask) -> AgentResult:
        started = perf_counter()
        leads = [Lead.model_validate(item) for item in task.input.get("leads", [])]
        await self.log(task.execution_id, "enrichment", "Enrichissement des prospects", {"count": len(leads)})

        enriched = []
        errors = []
        for lead in leads:
            try:
                enriched.append(await self._enrich_one(lead))
            except Exception as exc:
                errors.append(f"{lead.name}: {str(exc)[:200]}")
                enriched.append(lead)

        return self.result(task, results={"leads": [lead.model_dump() for lead in enriched]}, errors=errors, start_time=started)

    async def _enrich_one(self, lead: Lead) -> Lead:
        if lead.website:
            scraper = self.tools.get("website_scraper")
            if scraper:
                raw = await scraper.run(lead.website)
                scraped = normalize_source_lead(raw, "website")
                if scraped:
                    for field in ["email", "phone", "facebook", "instagram", "linkedin", "contact_form"]:
                        value = getattr(scraped, field, None)
                        if value and not getattr(lead, field, None):
                            setattr(lead, field, value)
                    lead.sources = list(dict.fromkeys(lead.sources + ["website"]))

        if not any([lead.email, lead.phone, lead.facebook, lead.instagram, lead.linkedin]):
            serper = self.tools.get("serper")
            if serper:
                results = await serper.run(f"{lead.name} {lead.city or ''} contact", platform="general")
                for item in results or []:
                    found = normalize_source_lead(item, "serper")
                    if found and found.website and not lead.website:
                        lead.website = found.website
                        lead.sources.append("serper")
                        break

        lead.status = "enriched"
        return lead
