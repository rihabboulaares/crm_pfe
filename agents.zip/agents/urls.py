from django.urls import path

from agents.api.views import (
    AgentExecutionCancelView,
    AgentExecutionDetailView,
    AgentExecutionListView,
    AgentExecutionRetryView,
    AgentRunView,
)

urlpatterns = [
    path("prospection-agents/<str:agent_type>/run/", AgentRunView.as_view(), name="prospection-agent-run"),
    path("prospection-agents/executions/", AgentExecutionListView.as_view(), name="prospection-agent-executions"),
    path("prospection-agents/executions/<int:pk>/", AgentExecutionDetailView.as_view(), name="prospection-agent-execution"),
    path("prospection-agents/executions/<int:pk>/retry/", AgentExecutionRetryView.as_view(), name="prospection-agent-retry"),
    path("prospection-agents/executions/<int:pk>/cancel/", AgentExecutionCancelView.as_view(), name="prospection-agent-cancel"),
]
