from agents.tools.meta_ads_tool import MetaAdsTool


def build_tools() -> dict:
    from agentProspection.tools.maps_tool import MapsTool
    from agentProspection.tools.serper_tool import SerperTool
    from agentProspection.tools.website_scraper import WebsiteScraperTool

    return {
        "maps": MapsTool(),
        "serper": SerperTool(),
        "website_scraper": WebsiteScraperTool(),
        "meta_ads": MetaAdsTool(),
    }
