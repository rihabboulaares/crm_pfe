class MetaAdsTool:
    name = "meta_ads"

    async def run(self, query: str) -> list[dict]:
        return []
