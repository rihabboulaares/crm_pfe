from types import SimpleNamespace
from unittest.mock import patch

from django.test import TestCase
from rest_framework.test import APIRequestFactory, force_authenticate

from agentEngagement.models import EngagementLog
from sales.models import Prospect, ProspectActivity, ProspectCompany
from users.models import Company, User

from .agent.qualification_runtime import QualificationRuntime
from .models import ProspectQualification
from .views import ProspectQualificationHistoryView, ProspectQualificationRunView


def gemini_response(payload):
    import json

    return SimpleNamespace(text=json.dumps(payload))


class QualificationAgentTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email="owner@example.com",
            username="owner",
            password="pass",
        )
        self.company = Company.objects.create(owner=self.user, name="Acme")
        self.user.company = self.company
        self.user.save(update_fields=["company"])
        self.prospect_company = ProspectCompany.objects.create(
            name="TechNova",
            company=self.company,
            email="contact@technova.test",
            phone="+21670000000",
        )

    def make_prospect(self, **overrides):
        defaults = {
            "first_name": "Amine",
            "last_name": f"Lead{Prospect.objects.count()}",
            "title": "Responsable RH",
            "email": f"lead{Prospect.objects.count()}@example.com",
            "phone": "+21620000000",
            "city": "Tunis",
            "country": "Tunisie",
            "description": "Prospect trouvé par prospection.",
            "company": self.company,
            "assigned_to": self.user,
            "prospect_company": self.prospect_company,
            "source": "agent_prospection",
            "lead_origin": "prospection_agent",
        }
        defaults.update(overrides)
        return Prospect.objects.create(**defaults)

    def ai_payload(self, **overrides):
        payload = {
            "need_level": "UNKNOWN",
            "intent_level": "UNKNOWN",
            "urgency_level": "UNKNOWN",
            "budget_signal": "UNKNOWN",
            "authority_level": "INFLUENCER",
            "engagement_quality": "NONE",
            "detected_needs": [],
            "objections": [],
            "buying_signals": [],
            "missing_information": ["Budget", "Timing"],
            "summary": "Bon profil, mais aucun échange commercial confirmé.",
        }
        payload.update(overrides)
        return payload

    def run_with_ai(self, prospect, payload):
        with patch("agentQualification.agent.nodes.qualification_reasoner.get_gemini_model") as model:
            with patch("agentQualification.agent.nodes.qualification_reasoner.generate_with_retry") as generate:
                model.return_value = object()
                generate.return_value = gemini_response(payload)
                return QualificationRuntime().run(prospect, self.user)

    def test_initial_qualification_without_interactions(self):
        prospect = self.make_prospect()
        result = self.run_with_ai(prospect, self.ai_payload())

        self.assertEqual(result["mode"], "INITIAL")
        self.assertEqual(result["status"], "ENGAGE")
        self.assertFalse(result["opportunity_ready"])
        self.assertEqual(ProspectQualification.objects.count(), 1)
        self.assertGreaterEqual(result["score"], 0)
        self.assertLessEqual(result["score"], 100)

    def test_positive_interaction_switches_to_post_engagement(self):
        prospect = self.make_prospect()
        ProspectActivity.objects.create(
            prospect=prospect,
            activity_type="message_sent",
            channel="linkedin",
            title="Message LinkedIn envoyé",
            description="Premier message envoyé.",
            source="manual",
            created_by=self.user,
            metadata={
                "kind": "engagement_interaction",
                "channel": "LINKEDIN",
                "action_type": "SOCIAL_MESSAGE_SENT",
                "outcome": "INTERESTED",
                "prospect_response": "Nous réfléchissons à remplacer notre outil RH.",
            },
        )

        result = self.run_with_ai(
            prospect,
            self.ai_payload(
                need_level="HIGH",
                intent_level="MEDIUM",
                engagement_quality="POSITIVE",
                detected_needs=["Remplacement outil RH"],
                buying_signals=["Besoin confirmé"],
            ),
        )

        self.assertEqual(result["mode"], "POST_ENGAGEMENT")
        self.assertIn(result["status"], {"DEEPEN", "READY_FOR_OPPORTUNITY"})
        self.assertIn("Remplacement outil RH", result["detected_needs"])

    def test_refusal_is_not_qualified(self):
        prospect = self.make_prospect()
        ProspectActivity.objects.create(
            prospect=prospect,
            activity_type="reply_received",
            channel="email",
            title="Réponse reçue",
            description="Merci de ne plus nous contacter.",
            source="manual",
            created_by=self.user,
            metadata={
                "kind": "engagement_interaction",
                "channel": "EMAIL",
                "action_type": "EMAIL_SENT",
                "outcome": "NOT_INTERESTED",
                "prospect_response": "Merci de ne plus nous contacter.",
            },
        )

        result = self.run_with_ai(
            prospect,
            self.ai_payload(
                intent_level="LOW",
                engagement_quality="NEGATIVE",
                objections=["Ne plus contacter"],
            ),
        )

        self.assertEqual(result["status"], "NOT_QUALIFIED")
        self.assertEqual(result["recommended_action"], "DO_NOT_CONTACT")

    def test_insufficient_data_keeps_score_in_bounds(self):
        prospect = self.make_prospect(
            title="",
            email=None,
            phone=None,
            prospect_company=None,
            description="",
        )
        result = self.run_with_ai(prospect, self.ai_payload(authority_level="UNKNOWN"))

        self.assertGreaterEqual(result["score"], 0)
        self.assertLessEqual(result["score"], 100)
        self.assertIn("Email ou téléphone", result["missing_information"])

    def test_need_without_timing_stays_deepen(self):
        prospect = self.make_prospect()
        ProspectActivity.objects.create(
            prospect=prospect,
            activity_type="message_sent",
            channel="email",
            title="Email envoyé",
            description="Réponse reçue",
            source="manual",
            created_by=self.user,
            metadata={
                "kind": "engagement_interaction",
                "channel": "EMAIL",
                "action_type": "EMAIL_SENT",
                "outcome": "REQUEST_INFORMATION",
                "prospect_response": "Nous cherchons une solution mais pas de date définie.",
            },
        )

        result = self.run_with_ai(
            prospect,
            self.ai_payload(
                need_level="HIGH",
                intent_level="MEDIUM",
                urgency_level="UNKNOWN",
                engagement_quality="POSITIVE",
                detected_needs=["Recherche de solution"],
                buying_signals=[],
            ),
        )

        self.assertEqual(result["status"], "DEEPEN")
        self.assertFalse(result["opportunity_ready"])

    def test_ready_for_opportunity_requires_business_rules(self):
        prospect = self.make_prospect(title="Directeur RH")
        ProspectActivity.objects.create(
            prospect=prospect,
            activity_type="reply_received",
            channel="email",
            title="Réponse positive",
            description="Démonstration acceptée la semaine prochaine.",
            source="manual",
            created_by=self.user,
            metadata={
                "kind": "engagement_interaction",
                "channel": "EMAIL",
                "action_type": "EMAIL_SENT",
                "outcome": "MEETING_REQUEST",
                "prospect_response": "Nous voulons changer avant janvier et organiser une démonstration.",
            },
        )

        result = self.run_with_ai(
            prospect,
            self.ai_payload(
                need_level="HIGH",
                intent_level="HIGH",
                urgency_level="HIGH",
                budget_signal="POSITIVE",
                authority_level="DECISION_MAKER",
                engagement_quality="STRONG",
                detected_needs=["Changer l'outil actuel"],
                buying_signals=["Demande de démonstration", "Échéance communiquée"],
                missing_information=[],
            ),
        )

        self.assertEqual(result["status"], "READY_FOR_OPPORTUNITY")
        self.assertTrue(result["opportunity_ready"])
        self.assertEqual(result["recommended_action"], "CREATE_OPPORTUNITY")

    def test_invalid_json_is_repaired_once(self):
        prospect = self.make_prospect()
        repaired = self.ai_payload(need_level="MEDIUM", intent_level="MEDIUM")
        with patch("agentQualification.agent.nodes.qualification_reasoner.get_gemini_model") as model:
            with patch("agentQualification.agent.nodes.qualification_reasoner.generate_with_retry") as generate:
                with patch("agentQualification.agent.nodes.qualification_reasoner.repair_json_with_gemini") as repair:
                    model.return_value = object()
                    generate.return_value = SimpleNamespace(text="{invalid")
                    repair.return_value = repaired
                    result = QualificationRuntime().run(prospect, self.user)

        self.assertEqual(result["status"], "ENGAGE")
        self.assertEqual(repair.call_count, 1)

    def test_gemini_unavailable_persists_incomplete_result(self):
        prospect = self.make_prospect()
        with patch("agentQualification.agent.nodes.qualification_reasoner.get_gemini_model") as model:
            model.side_effect = RuntimeError("429 RESOURCE_EXHAUSTED")
            result = QualificationRuntime().run(prospect, self.user)

        self.assertEqual(result["status"], "ANALYSIS_INCOMPLETE")
        self.assertEqual(result["recommended_action"], "RETRY_QUALIFICATION")
        self.assertEqual(ProspectQualification.objects.count(), 1)

    def test_user_without_permission_cannot_run(self):
        other_user = User.objects.create_user(email="other@example.com", username="other", password="pass")
        other_company = Company.objects.create(owner=other_user, name="Other")
        other_user.company = other_company
        other_user.save(update_fields=["company"])
        prospect = self.make_prospect()

        request = APIRequestFactory().post(f"/api/qualification/prospects/{prospect.id}/run/")
        force_authenticate(request, user=other_user)
        response = ProspectQualificationRunView.as_view()(request, prospect_id=prospect.id)

        self.assertEqual(response.status_code, 403)

    def test_history_keeps_multiple_qualifications(self):
        prospect = self.make_prospect()
        self.run_with_ai(prospect, self.ai_payload())
        self.run_with_ai(
            prospect,
            self.ai_payload(
                need_level="MEDIUM",
                intent_level="MEDIUM",
                engagement_quality="POSITIVE",
            ),
        )

        request = APIRequestFactory().get(f"/api/qualification/prospects/{prospect.id}/history/")
        force_authenticate(request, user=self.user)
        response = ProspectQualificationHistoryView.as_view()(request, prospect_id=prospect.id)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data["results"]), 2)
        self.assertIsNotNone(response.data["results"][0]["previous_score"])

    def test_engagement_log_is_used_as_interaction(self):
        prospect = self.make_prospect()
        EngagementLog.objects.create(
            prospect=prospect,
            user=self.user,
            company=self.company,
            action="replied",
            channel="email",
            message="Pouvez-vous envoyer les tarifs ?",
            status="replied",
        )

        result = self.run_with_ai(
            prospect,
            self.ai_payload(
                need_level="MEDIUM",
                intent_level="HIGH",
                engagement_quality="POSITIVE",
                buying_signals=["Question commerciale précise"],
            ),
        )

        self.assertEqual(result["mode"], "POST_ENGAGEMENT")

