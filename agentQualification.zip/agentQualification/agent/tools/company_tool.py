def serialize_company(company):
    if not company:
        return None
    return {
        "id": company.id,
        "name": company.name,
        "sector": getattr(company, "sector", "") or getattr(company, "industry", ""),
        "city": getattr(company, "city", ""),
        "country": getattr(company, "country", ""),
        "website": getattr(company, "website", ""),
        "source": getattr(company, "source", ""),
        "score_ia": getattr(company, "score_ia", None),
        "evaluation": getattr(company, "evaluation", ""),
    }

