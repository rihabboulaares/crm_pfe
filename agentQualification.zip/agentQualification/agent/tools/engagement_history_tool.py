def list_engagement_logs(prospect, limit=100):
    logs = prospect.engagement_logs.select_related("user").order_by("-created_at")[:limit]
    return [
        {
            "id": log.id,
            "action": log.action,
            "channel": log.channel or "",
            "message": log.message or "",
            "status": log.status,
            "error": log.error or log.error_message or "",
            "sent_at": log.sent_at,
            "created_at": log.created_at,
            "sender_email": log.sender_email or "",
            "provider": log.provider or "",
        }
        for log in logs
    ]


def extract_engagement_interactions(activities, engagement_logs):
    interactions = []
    for activity in activities:
        metadata = activity.get("metadata") or {}
        if metadata.get("kind") == "engagement_interaction":
            interactions.append(
                {
                    "source": "prospect_activity",
                    "id": activity.get("id"),
                    "channel": metadata.get("channel") or activity.get("channel"),
                    "action_type": metadata.get("action_type") or activity.get("activity_type"),
                    "outcome": metadata.get("outcome") or "",
                    "prospect_response": metadata.get("prospect_response") or "",
                    "commercial_notes": metadata.get("commercial_notes") or "",
                    "message": metadata.get("generated_content_reference") or activity.get("description") or "",
                    "created_at": activity.get("created_at"),
                }
            )
        elif activity.get("activity_type") in {"message_sent", "email_sent", "reply_received", "call_done"}:
            interactions.append(
                {
                    "source": "prospect_activity",
                    "id": activity.get("id"),
                    "channel": activity.get("channel"),
                    "action_type": activity.get("activity_type"),
                    "outcome": activity.get("activity_type"),
                    "prospect_response": activity.get("description") if activity.get("activity_type") == "reply_received" else "",
                    "commercial_notes": "",
                    "message": activity.get("description") or "",
                    "created_at": activity.get("created_at"),
                }
            )

    for log in engagement_logs:
        if log.get("action") in {"message_sent", "replied", "message_generated", "follow_up_created"}:
            interactions.append(
                {
                    "source": "engagement_log",
                    "id": log.get("id"),
                    "channel": log.get("channel"),
                    "action_type": log.get("action"),
                    "outcome": log.get("status"),
                    "prospect_response": log.get("message") if log.get("action") == "replied" else "",
                    "commercial_notes": "",
                    "message": log.get("message") or "",
                    "created_at": log.get("sent_at") or log.get("created_at"),
                }
            )

    return sorted(interactions, key=lambda item: str(item.get("created_at") or ""))

