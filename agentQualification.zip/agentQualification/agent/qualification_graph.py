from agentQualification.agent.nodes.analyze_interactions import analyze_interactions
from agentQualification.agent.nodes.analyze_profile import analyze_profile
from agentQualification.agent.nodes.calculate_signals import calculate_signals
from agentQualification.agent.nodes.decision_node import decision_node
from agentQualification.agent.nodes.load_context import load_context
from agentQualification.agent.nodes.persist_result import persist_result
from agentQualification.agent.nodes.qualification_reasoner import (
    QualificationAIUnavailable,
    qualification_reasoner,
)


class QualificationGraph:
    def run(self, state, prospect, user, request=None):
        state = load_context(state, prospect, request=request)
        state = analyze_profile(state)
        state = analyze_interactions(state)
        try:
            state = qualification_reasoner(state)
            state["confidence"] = self._confidence(state)
            state = calculate_signals(state)
            state = decision_node(state)
        except QualificationAIUnavailable:
            state["ai_result"] = None
            state = calculate_signals(state)
            state.update(
                {
                    "status": "ANALYSIS_INCOMPLETE",
                    "opportunity_ready": False,
                    "recommended_action": "RETRY_QUALIFICATION",
                    "confidence": 0.0,
                    "strengths": [],
                    "risks": ["Analyse IA indisponible"],
                    "summary": "La qualification n'a pas pu être terminée pour le moment.",
                }
            )
        state = persist_result(state, prospect, user)
        return state

    def _confidence(self, state):
        profile = state.get("profile_signals") or {}
        interactions = state.get("interaction_signals") or {}
        ai = state.get("ai_result") or {}
        known_ai = sum(
            1
            for key in [
                "need_level",
                "intent_level",
                "urgency_level",
                "budget_signal",
                "authority_level",
                "engagement_quality",
            ]
            if ai.get(key) and ai.get(key) not in {"UNKNOWN", "NONE"}
        )
        contact_factor = min(0.30, (profile.get("present_contact_channels", 0) or 0) * 0.08)
        interaction_factor = min(0.25, (interactions.get("significant_interactions", 0) or 0) * 0.08)
        ai_factor = min(0.35, known_ai * 0.06)
        return round(min(0.95, 0.10 + contact_factor + interaction_factor + ai_factor), 2)

