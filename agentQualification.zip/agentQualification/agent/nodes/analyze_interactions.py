SIGNIFICANT_OUTCOMES = {
    "INTERESTED",
    "CALL_LATER",
    "OBJECTION",
    "REQUEST_INFORMATION",
    "MEETING_REQUEST",
    "SENT",
    "reply_received",
    "message_sent",
    "replied",
}


def has_significant_interaction(interaction):
    if interaction.get("prospect_response"):
        return True
    if interaction.get("commercial_notes"):
        return True
    if interaction.get("outcome") in SIGNIFICANT_OUTCOMES:
        return True
    if interaction.get("action_type") in {"message_sent", "replied", "EMAIL_SENT", "PHONE_CALL", "SOCIAL_MESSAGE_SENT"}:
        return True
    return False


def analyze_interactions(state):
    interactions = state.get("interactions") or []
    significant = [item for item in interactions if has_significant_interaction(item)]
    state["qualification_mode"] = "POST_ENGAGEMENT" if significant else "INITIAL"
    state["interaction_signals"] = {
        "total_interactions": len(interactions),
        "significant_interactions": len(significant),
        "has_prospect_response": any(item.get("prospect_response") for item in interactions),
        "has_meeting_request": any(item.get("outcome") == "MEETING_REQUEST" for item in interactions),
        "has_objection": any(item.get("outcome") == "OBJECTION" for item in interactions),
        "has_positive_interest": any(item.get("outcome") in {"INTERESTED", "MEETING_REQUEST"} for item in interactions),
    }
    return state

