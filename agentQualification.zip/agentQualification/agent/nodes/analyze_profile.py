ROLE_KEYWORDS = {
    "decision": ["directeur", "ceo", "founder", "fondateur", "responsable", "head", "manager", "admin"],
    "relevant": ["rh", "commercial", "marketing", "achat", "finance", "it", "technique", "operations"],
}


def _contains_any(text, keywords):
    normalized = str(text or "").lower()
    return any(keyword in normalized for keyword in keywords)


def analyze_profile(state):
    prospect = state.get("prospect") or {}
    company = state.get("company") or {}
    missing = []

    profile_fields = ["first_name", "last_name", "title", "description", "source"]
    present_profile = sum(1 for field in profile_fields if prospect.get(field))
    profile_fit_score = min(100, 35 + present_profile * 10)

    company_fields = ["name", "sector", "city", "country", "website"]
    present_company = sum(1 for field in company_fields if company and company.get(field))
    company_fit_score = min(100, 30 + present_company * 12) if company else 20

    title = prospect.get("title") or ""
    if _contains_any(title, ROLE_KEYWORDS["decision"]):
        contact_relevance_score = 85
    elif _contains_any(title, ROLE_KEYWORDS["relevant"]):
        contact_relevance_score = 68
    elif title:
        contact_relevance_score = 50
    else:
        contact_relevance_score = 25
        missing.append("Poste du contact")

    contact_fields = ["email", "phone", "linkedin_url", "facebook_url", "instagram_url", "website"]
    present_contact = sum(1 for field in contact_fields if prospect.get(field))
    reachability_score = min(100, present_contact * 22)
    if not prospect.get("email") and not prospect.get("phone"):
        missing.append("Email ou téléphone")
    if not company:
        missing.append("Entreprise")

    state["profile_signals"] = {
        "profile_fit_score": profile_fit_score,
        "company_fit_score": company_fit_score,
        "contact_relevance_score": contact_relevance_score,
        "reachability_score": reachability_score,
        "present_contact_channels": present_contact,
        "missing_profile_information": missing,
    }
    state["missing_information"] = sorted(set(state.get("missing_information", []) + missing))
    return state

